fox_and_ball
キツネの鳴き声が延々と鳴り響く中、ボールが所狭しと跳ね回るだけ。
http://aidiary.hatenablog.com/entry/20080507/1269694935 さんの記事を
参考にして、Pygameダウンロードして作ってみたもの。
ゲームではない（明らか）。
